﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ScheduledOrderService.Models
{
    public class ScheduledOrderServiceConfiguration
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public int ApplicationId { get; set; }
        public string BaseURL { get; set; }
        public string BearerTokenUrl { get; set; }
        public string ScheduledOrderIdsFetchUrl { get; set; }
        public string ScheduledOrderIdsForValidationFetchUrl { get; set; }
        public string ScheduledOrderProcessUrl { get; set; }
        public string ScheduledOrderValidationUrl { get; set; }
        public string AddScheduledOrderServiceLogUrl { get; set; }
        public int ScheduledOrderProcessInterval { get; set; }
    }
}
