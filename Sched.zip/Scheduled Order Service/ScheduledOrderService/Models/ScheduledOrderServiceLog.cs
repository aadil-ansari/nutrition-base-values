﻿namespace ScheduledOrderService.Models
{
    public class ScheduledOrderServiceLog
    {
        public string Endpoint { get; set; }

        public string Description { get; set; }

        public string ErrorMessage { get; set; }

        public string UserName { get; set; }
    }
}
