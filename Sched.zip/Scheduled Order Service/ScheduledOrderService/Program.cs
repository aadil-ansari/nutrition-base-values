﻿using System;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ScheduledOrderService.Models;
using Serilog;

namespace ScheduledOrderService
{
    class Program
    {
        static void Main(string[] args)
        {
            IConfiguration config = new ConfigurationBuilder()
                .AddJsonFile("appSettings.json")
                .Build();

            Log.Logger = new LoggerConfiguration()
             .Enrich.FromLogContext()
               .WriteTo.File(config.GetSection("SheduledOrderServiceLogPath").Value)
             .CreateLogger();
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args).UseWindowsService()
                .ConfigureServices((hostContext, services) =>
                {
                    var configuration = hostContext.Configuration;
                    var options = configuration.GetSection("ScheduledOrderServiceConfiguration").Get<ScheduledOrderServiceConfiguration>();

                    services.AddSingleton(options);
                    services.AddHostedService<ScheduledOrderService>();

                }).UseSerilog();
    }
}

