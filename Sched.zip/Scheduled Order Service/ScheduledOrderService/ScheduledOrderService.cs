﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using ScheduledOrderService.Models;

namespace ScheduledOrderService
{
    public class ScheduledOrderService : BackgroundService
    {
        private readonly ILogger<ScheduledOrderService> _logger;
        private readonly ScheduledOrderServiceConfiguration _serviceConfiguration;
        private string AuthToken;

        public ScheduledOrderService(ILogger<ScheduledOrderService> logger, ScheduledOrderServiceConfiguration serviceConfiguration)
        {
            _logger = logger;
            _serviceConfiguration = serviceConfiguration;
        }

        public override Task StartAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("The ScheduledOrderService has started.");
            return base.StartAsync(cancellationToken);
        }
        public override Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("The ScheduledOrderService has stopped.");
            return base.StopAsync(cancellationToken);
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                _logger.LogInformation($"ScheduledOrderWorker running at: {DateTime.UtcNow}");

                await SetAuthToken();

                if (!string.IsNullOrEmpty(AuthToken))
                {
                    await ProcessScheduledOrders();
                    await ValidateScheduledOrders();
                }

                AuthToken = null;
                
                await Task.Delay(TimeSpan.FromMinutes(_serviceConfiguration.ScheduledOrderProcessInterval), stoppingToken);
            }
        }

        private async Task SetAuthToken()
        {
            if (!string.IsNullOrEmpty(AuthToken))
            {
                return;
            }

            AuthPostRequest requestObj = new AuthPostRequest()
            {
                Username = _serviceConfiguration.Username,
                Password = _serviceConfiguration.Password,
                AppId = _serviceConfiguration.ApplicationId
            };

            var requestEndPoint = $"{_serviceConfiguration.BaseURL}/{_serviceConfiguration.BearerTokenUrl}";
            var requestBody = JsonConvert.SerializeObject(requestObj);

            _logger.LogInformation("SetAuthToken() EndPoint: " + requestEndPoint);

            try
            {
                using (var client = new HttpClient())
                {
                    var response = await client.PostAsync(requestEndPoint, new StringContent(requestBody, Encoding.UTF8, "application/json"));

                    if (response.IsSuccessStatusCode)
                    {
                        AuthToken = response.Content.ReadAsStringAsync().Result;
                        await AddScheduledOrderServiceLog(requestEndPoint, AuthToken, null);
                    }
                    else
                    {
                        _logger.LogError($"SetAuthToken(): {response.Content.ReadAsStringAsync().Result}");
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"SetAuthToken(): {ex?.InnerException?.ToString() ?? ex.ToString()}");
            }
        }

        private async Task<List<int>> GetScheduledOrderIds()
        {
            List<int> scheduledOrderIds = new List<int>();
            var requestEndPoint = $"{_serviceConfiguration.BaseURL}/{_serviceConfiguration.ScheduledOrderIdsFetchUrl}";

            try
            {
                using (var client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Clear();
                    client.DefaultRequestHeaders.Add("Authorization", "Bearer " + AuthToken);

                    _logger.LogInformation("GetScheduledOrderIds() EndPoint: " + requestEndPoint);

                    var response = await client.GetStringAsync(requestEndPoint);

                    await AddScheduledOrderServiceLog(requestEndPoint, $"Fetch OrderIDs for processing: {response}", null);

                    scheduledOrderIds = JsonConvert.DeserializeObject<List<int>>(response);
                }
            }
            catch (Exception ex)
            {
                var errorMsg = ex?.InnerException?.ToString() ?? ex.ToString();
                
                _logger.LogError($"GetScheduledOrderIds(): {errorMsg}");
                
                await AddScheduledOrderServiceLog(requestEndPoint, "Fetch OrderIDs for processing: ERROR", errorMsg);
            }
             
            return scheduledOrderIds;
        }

        private async Task<List<int>> GetScheduledOrderIdsForValidation()
        {
            List<int> scheduledOrderIds = new List<int>();
            var requestEndPoint = $"{_serviceConfiguration.BaseURL}/{_serviceConfiguration.ScheduledOrderIdsForValidationFetchUrl}";

            try
            {
                using (var client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Clear();
                    client.DefaultRequestHeaders.Add("Authorization", "Bearer " + AuthToken);

                    _logger.LogInformation("GetScheduledOrderIdsForValidation() EndPoint: " + requestEndPoint);

                    var response = await client.GetStringAsync(requestEndPoint);

                    await AddScheduledOrderServiceLog(requestEndPoint, $"Fetch OrderIDs for validation: {response}", null);

                    scheduledOrderIds = JsonConvert.DeserializeObject<List<int>>(response);
                }
            }
            catch (Exception ex)
            {
                var errorMsg = ex?.InnerException?.ToString() ?? ex.ToString();

                _logger.LogError($"GetScheduledOrderIdsForValidation: {errorMsg}");

                await AddScheduledOrderServiceLog(requestEndPoint, "Fetch OrderIDs for validation: ERROR", errorMsg);
            }

            return scheduledOrderIds;
        }

        private async Task ProcessScheduledOrders()
        {
            var scheduledOrderIds = await GetScheduledOrderIds();
            
            if((scheduledOrderIds?.Count ?? 0) == 0)
            {
                _logger.LogInformation($"ProcessScheduledOrders: No Scheduled Orders Found");
                return;
            }

            foreach (var orderId in scheduledOrderIds)
            {
                await ProcessScheduledOrderById(orderId);
            }

        }

        private async Task ValidateScheduledOrders()
        {
            var scheduledOrderIds = await GetScheduledOrderIdsForValidation();
            
            if ((scheduledOrderIds?.Count ?? 0) == 0)
            {
                _logger.LogInformation($"ValidateScheduledOrders: No Scheduled Orders Found");
                return;
            }

            foreach (var orderId in scheduledOrderIds)
            {
                await ValidateScheduledOrderById(orderId);
            }

        }

        private async Task ProcessScheduledOrderById(int orderId)
        {
            var requestEndPoint = $"{_serviceConfiguration.BaseURL}/{_serviceConfiguration.ScheduledOrderProcessUrl}";
            var formattedUrl = requestEndPoint.Replace("{orderID}", orderId.ToString());

            try
            {
                using (var client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Add("Authorization", "Bearer " + AuthToken);

                    var requestData = JsonConvert.SerializeObject(orderId);

                    _logger.LogInformation("ProcessScheduledOrderById() EndPoint: " + formattedUrl);

                    var processResponse = await client.PostAsync(formattedUrl, new StringContent(requestData, Encoding.UTF8, "application/json"));

                    if (processResponse.IsSuccessStatusCode)
                    {
                        _logger.LogInformation($"ProcessScheduledOrderById: Scheduled Order: {orderId}, Process Success.");

                        await AddScheduledOrderServiceLog(formattedUrl, $"OrderID {orderId} is processed successfully", null);
                    }
                    else
                    {
                        var errorMsg = processResponse.Content.ReadAsStringAsync().Result;

                        _logger.LogError($"ProcessScheduledOrderById(): Scheduled Order: {orderId}, Process Failed. Error Info: {errorMsg}");

                        await AddScheduledOrderServiceLog(formattedUrl, $"Processing OrderID {orderId}: ERROR", errorMsg);
                    }
                }
            }
            catch (Exception ex)
            {
                var errorMsg = ex?.InnerException?.ToString() ?? ex.ToString();

                _logger.LogError($"ProcessScheduledOrderById:Scheduled Order: {orderId}, Exception Log: {errorMsg}");

                await AddScheduledOrderServiceLog(formattedUrl, $"Processing OrderID {orderId}: ERROR", errorMsg);
            }
        }

        private async Task ValidateScheduledOrderById(int orderId)
        {
            var requestEndPoint = $"{_serviceConfiguration.BaseURL}/{_serviceConfiguration.ScheduledOrderValidationUrl}";
            var formattedUrl = requestEndPoint.Replace("{orderID}", orderId.ToString());

            try
            {
                using (var client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Add("Authorization", "Bearer " + AuthToken);

                    var requestData = JsonConvert.SerializeObject(orderId);

                    _logger.LogInformation("ValidateScheduledOrderById() EndPoint: " + formattedUrl);

                    var processResponse = await client.PostAsync(formattedUrl, new StringContent(requestData, Encoding.UTF8, "application/json"));

                    if (processResponse.IsSuccessStatusCode)
                    {
                        _logger.LogInformation($"ValidateScheduledOrderById : Scheduled Order : {orderId}, Validation Success.");
                        
                        await AddScheduledOrderServiceLog(formattedUrl, $"OrderID {orderId} is validated successfully", null);
                    }
                    else
                    {
                        var errorMsg = processResponse.Content.ReadAsStringAsync().Result;

                        _logger.LogError($"ValidateScheduledOrderById : Scheduled Order : {orderId}, Process Failed. Error Info: {errorMsg}");

                        await AddScheduledOrderServiceLog(formattedUrl, $"Validating OrderID {orderId}: ERROR", errorMsg);
                    }
                }
            }
            catch (Exception ex)
            {
                var errorMsg = ex?.InnerException?.ToString() ?? ex.ToString();

                _logger.LogError($"ValidateScheduledOrderById : Scheduled Order : {orderId}, Exception Log: {errorMsg}");

                await AddScheduledOrderServiceLog(formattedUrl, $"Validating OrderID {orderId}: ERROR", errorMsg);
            }
        }

        private async Task AddScheduledOrderServiceLog(string Endpoint, string Description, string ErrorMessage)
        {
            var requestObject = new ScheduledOrderServiceLog
            {
                Endpoint = Endpoint,
                Description = Description,
                ErrorMessage = ErrorMessage,
                UserName = _serviceConfiguration.Username
            };

            var requestEndPoint = $"{_serviceConfiguration.BaseURL}/{_serviceConfiguration.AddScheduledOrderServiceLogUrl}";
            var requestBody = JsonConvert.SerializeObject(requestObject);

            try
            {
                using (var client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Add("Authorization", "Bearer " + AuthToken);
                    
                    var response = await client.PostAsync(requestEndPoint, new StringContent(requestBody, Encoding.UTF8, "application/json"));

                    if (!response.IsSuccessStatusCode)
                    {
                        _logger.LogError($"AddScheduledOrderServiceLog(): {response.Content.ReadAsStringAsync().Result}");
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"AddScheduledOrderServiceLog(): {ex?.InnerException?.ToString() ?? ex.ToString()}");
            }
        }
    }
}
