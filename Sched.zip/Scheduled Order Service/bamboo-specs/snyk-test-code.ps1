param($vurlSevLevel="high")

npm list snyk -g; If($LASTEXITCODE -gt 0) {npm install snyk -g}
npm list snyk-to-html -g; If($LASTEXITCODE -gt 0) { npm install snyk-to-html -g}

npx snyk auth 77480bec-f2bb-4350-bc50-b2cb243ba9f4

npx snyk code test --all-projects --severity-threshold=$vurlSevLevel --json-file-output=vul_results-code.json
if ($LASTEXITCODE) {
    npx snyk-to-html -i vul_results-code.json -o report-code.html
}

Remove-item vul_results-code.json -ErrorAction Ignore

