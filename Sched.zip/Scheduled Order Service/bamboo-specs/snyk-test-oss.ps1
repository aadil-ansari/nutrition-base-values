param($vurlSevLevel="high")

npm list snyk -g; If($LASTEXITCODE -gt 0) {npm install snyk -g}
npm list snyk-to-html -g; If($LASTEXITCODE -gt 0) { npm install snyk-to-html -g}

npx snyk auth 77480bec-f2bb-4350-bc50-b2cb243ba9f4

npx snyk test --all-projects --severity-threshold=$vurlSevLevel --json-file-output=vul_results-oss.json
if ($LASTEXITCODE) {
    npx snyk-to-html -i vul_results-oss.json -o report-oss.html
}

Remove-item vul_results-oss.json -ErrorAction Ignore

